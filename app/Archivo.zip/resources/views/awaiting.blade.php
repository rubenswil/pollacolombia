
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div style="text-align:center;" class="card-header"> <b> Awaiting Activation </b></div>

                <div class="card-body">
                    <center>

                            Porfavor espere a ser activado por uno de nuestros administradores.
                            <br>
                            <b>Someone Will be on touch soon, we appreciate your patience.</b>

                    </center>
                </div>
            </div>
        </div>
    </div>
</div>
