<html>

@include('partials.head')

@include('partials.header')

<body>

    @yield('content')

</body>

</html>